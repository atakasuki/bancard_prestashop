<?php
ob_start();
require_once dirname(dirname(dirname(__FILE__))).'/config/config.inc.php';
require_once dirname(dirname(dirname(__FILE__))).'/init.php';
require_once dirname(__FILE__).'/bancard.php';
$bancard = new Bancard();
$json = Tools::file_get_contents('php://input');
$data = json_decode($json);
if ($data) {
    if (isset($data->operation->shop_process_id) && $data->operation->shop_process_id != '') {
        $cart_id = Tools::substr($data->operation->shop_process_id, 0, -10);
        $cart = new Cart($cart_id);
        $customer = new Customer($cart->id_customer);
        $address = new Address($cart->id_address_delivery);
        Context::getContext()->country = new Country($address->id_country);
        $total = $cart->getOrderTotal(true, Cart::BOTH);
        $mail_vars = array();
        $query = 'INSERT INTO '._DB_PREFIX_.'bancard_response SET
        id_cart = '.(int)$cart_id.',
        order_number = "'.pSQL($data->operation->shop_process_id).'",
        response_code = "'.pSQL($data->operation->response_code).'",
        response_description = "'.pSQL($data->operation->response_description).'",
        authorization_number = "'.pSQL($data->operation->authorization_number).'"';
        $banresponse = Db::getInstance()->execute($query);
        $shop_id = pSQL($data->operation->shop_process_id);
        Db::getInstance()->execute('DELETE FROM '._DB_PREFIX_.'bancard_request where shop_process_id = "'.$shop_id.'"');
        if (isset($data) && $data->operation->response == 'S' && $data->operation->response_code == '00') {
            $bancard_complete = Configuration::get('BANCARD_PAYMENT_COMPLETE');
            $bancard->validateOrder(
                $cart_id,
                $bancard_complete,
                $total,
                $bancard->displayName,
                null,
                array(),
                null,
                false,
                $customer->secure_key
            );
        } else {
            $bancard->validateOrder(
                $cart_id,
                _PS_OS_ERROR_,
                $total,
                $bancard->displayName,
                null,
                array(),
                null,
                false,
                $customer->secure_key
            );
        }

        $result = [];
        $result['status'] = 'success';

        echo json_encode($result);
    }
}
