<?php
class BuyConfirmationController extends ModuleAdminController
{
    public function ajaxProcessBuyconfirmation()
    {
        $response = $this->l('No hay resultado para este ID de pedido en bancard.', 'bancard');
        $ido = (int)Tools::getValue('id_order');
        if ($ido) {
            require_once(dirname(__FILE__) . '/../../api/bancard.php');
            $arr_pk = array('BANCARD_PUBLIC_KEY', 'BANCARD_PRIVATE_KEY', 'BANCARD_PAYMENT_MODE');
            $config = Configuration::getMultiple($arr_pk);
            $bpk = $config['BANCARD_PUBLIC_KEY'];
            $bprk = $config['BANCARD_PRIVATE_KEY'];
            $bpm = $config['BANCARD_PAYMENT_MODE'];
            if ($order = new Order($ido)) {
                $idc = (int)$order->id_cart;
                $cart  = new Cart($idc);
                $total = (float)$cart->getOrderTotal(true, Cart::BOTH);
                $qu_resp = 'SELECT * FROM '._DB_PREFIX_.'bancard_response WHERE id_cart = '.$idc.'';
                $responsedata = Db::getInstance()->executeS($qu_resp);
                //var_dump($responsedata);
                if (!empty($responsedata)) {
                    $shopid = $responsedata[0]['order_number'];
                    $response = BancardApi::bancardConfirmation($bpk, $bprk, $shopid, $idc, $ido, $total, $bpm);
                } else {
                    $query = 'SELECT * FROM '._DB_PREFIX_.'bancard_request WHERE id_cart = '.$idc.'';
                    $requestdata = Db::getInstance()->executeS($query);
                    if (!empty($requestdata)) {
                        $si = $requestdata[0]['shop_process_id'];
                        $response = BancardApi::bancardConfirmation($bpk, $bprk, $si, $idc, $ido, $total, $bpm);
                    } else {
                        $response = $this->l('No hay resultado para este ID de pedido en bancard.', 'bancard');
                    }
                }
                //var_dump($response);
            }
        }
        echo $response;
        die;
    }
}
