<?php
class BancardPaymentModuleFrontController extends ModuleFrontController
{
    public $ssl = true;
    public function initContent()
    {
        if (!Tools::getValue('managecards')) {
            $authorized = false;
            foreach (Module::getPaymentModules() as $module) {
                if ($module['name'] == 'bancard') {
                    $authorized = true;
                    break;
                }
            }
            if (!$authorized || !$this->module->currencyEnable()) {
                die($this->module->l('Este método de pago no esta habilitado.', 'validation'));
            }
        }

        $this->display_column_left = false;
        parent::initContent();

        $cart = $this->context->cart;
        $months = array(
            '01' => 'Jan',
            '02' => 'Feb',
            '03' => 'Mar',
            '04' => 'Apr',
            '05' => 'May',
            '06' => 'Jun',
            '07' => 'Jly',
            '08' => 'Aug',
            '09' => 'Sep',
            '10' => 'Oct',
            '11' => 'Nov',
            '12' => 'Dec'
        );
        $current_year = date('Y');
        $last_year = $current_year + 15;
        $years = array();
        for ($i = $current_year; $i <= $last_year; $i++) {
            $years[$i] = $i;
        }
        $customer = $this->context->customer;
        $payment_error_message = '';
        if (Tools::getValue('res') == 'e') {
            if (Tools::getValue('desc')) {
                $payment_error_message = Tools::getValue('desc');
            }
            $payment_error = 'Los detalles de pago no son válidos, póngase en contacto con el administrador';
        } else {
            $payment_error = '';
        }
        $Currency = new Currency($cart->id_currency);
        $curr_sign =$Currency->getSign();

        global $cookie;

        $currency_actual = new Currency($cookie->id_currency);
        $total = $cart->getOrderTotal(true, Cart::BOTH);
        if ($currency_actual->iso_code != 'PYG') {
            $currencyGp = new Currency(Currency::getIdByIsoCode('PYG'));
            $total = number_format($total * (float)$currencyGp->conversion_rate, 0, ',', '.');
        }

        $this->context->smarty->assign(array(
            'tpl_dir' => _PS_THEME_DIR_,
            'months' => $months,
            'sign' => $curr_sign,
            'years' => $years,
            'payment_error' => $payment_error,
            'payment_error_message' => $payment_error_message,
            'id_lang' => Tools::getValue('id_lang'),
            'firstname' => $customer->firstname,
            'lastname' => $customer->lastname,
            'nbProducts' => $cart->nbProducts(),
            'cust_currency' => $cart->id_currency,
            'currencies' => $this->module->getCurrency((int)$cart->id_currency),
            'total' => $total,
            'this_path' => $this->module->getPathUri(),
            'this_path_bw' => $this->module->getPathUri(),
            'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->module->name.'/'
        ));
        if (Tools::version_compare(_PS_VERSION_, '1.7', '<')) {
            $this->setTemplate('payment_execution_1_6.tpl');
        } else {
            $this->setTemplate('module:bancard/views/templates/front/payment_execution.tpl');
        }
    }
}
