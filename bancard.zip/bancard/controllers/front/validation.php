<?php
class BancardValidationModuleFrontController extends ModuleFrontController
{
    public function postProcess()
    {

        $this->display_column_left = false;
        $this->display_column_right = false;

        include_once(_PS_ROOT_DIR_.'/modules/bancard/api/bancard.php');
        $ps_below_7 = Tools::version_compare(_PS_VERSION_, '1.7', '<');
        $payment_error_message = '';
        $payment_error = '';
        if (Tools::getValue('res') == 'e') {
            if (Tools::getValue('desc')) {
                $payment_error_message = Tools::getValue('desc');
            }
            $payment_error = 'Los detalles de pago no son válidos, contacte con el administrador ';
        }
        $this->context->smarty->assign(array(
            'currentUrl' => $this->context->link->getModuleLink(
                $this->module->name,
                'validation',
                array(
                    'managecards' => (bool)Tools::getValue('managecards')
                )
            ),
            'payment_error' => $payment_error,
            'payment_error_message' => $payment_error_message
        ));


        if ($payment_error != '' || $payment_error_message != '') {
            if ((bool)Tools::getValue('managecards')) {
                if (!Tools::isSubmit('RegisterNewCard')) {
                    if ($ps_below_7) {
                        $this->setTemplate('payment_token_1_6.tpl');
                    } else {
                        $this->setTemplate('module:bancard/views/templates/front/payment_token.tpl');
                    }
                    return;
                }
            } else {
                $url = 'index.php?fc=module&module=bancard&controller=payment';
                $url .= '&managecards='.(bool)Tools::getValue('managecards');
                $url .= '&res=e&desc='.urlencode($payment_error_message);
                Tools::redirect($url);
            }
        }

        $b_p_k = Configuration::get('BANCARD_PUBLIC_KEY');
        $b_pr_k = Configuration::get('BANCARD_PRIVATE_KEY');
        $b_p_m = Configuration::get('BANCARD_PAYMENT_MODE');
        $use_token = Configuration::get('BANCARD_PAYMENT_OPTION');
        $cart = $this->context->cart;
        $ad_inv = $cart->id_address_invoice;
        $cart = $this->context->cart;
        $currency = $this->context->currency;
        $customer = new Customer($cart->id_customer);
        $total = (float)$cart->getOrderTotal(true, Cart::BOTH);
        $mail_vars = array();
        $this->context->smarty->assign(array(
            'nbProducts' => $this->context->cart->nbProducts()
        ));

        $ulimoIdTarjeta = Db::getInstance()->executeS(
            'SELECT MAX(card_id)+1 as "card_id" FROM `'._DB_PREFIX_.'bancard_cutsomer_cards`
            WHERE id_customer = "'.(int)$customer->id.'"'
        );


        if(empty($ulimoIdTarjeta) || $ulimoIdTarjeta == 'NULL'){
            $ulimoIdTarjeta = 1;
        }else{
            if(isset($ulimoIdTarjeta[0]['card_id'])){
                if($ulimoIdTarjeta[0]['card_id'] == NULL || $ulimoIdTarjeta[0]['card_id'] =='NULL'){
                    $ulimoIdTarjeta = 1;
                }else{
                    $ulimoIdTarjeta = $ulimoIdTarjeta[0]['card_id'];
                }
            }else{
                $ulimoIdTarjeta = 1;
            }
        }


        $this->context->smarty->assign(array(
            'ulimoIdTarjeta' => $ulimoIdTarjeta
        ));

        if (Tools::getValue('add_new_card')) {
            switch (Tools::getValue('status')) {
                case 'add_new_card_fail':
                    $url = 'index.php?fc=module&module=bancard&controller=validation';
                    $url .= '&managecards='.(bool)Tools::getValue('managecards');
                    $url .= '&res=e&desc='.urlencode(Tools::getValue('description'));
                    Tools::redirect($url);
                    break;
                case 'add_new_card_success':
                    Db::getInstance()->update(
                        'bancard_cutsomer_cards',
                        array(
                            'success' => true,
                        ),
                        'id_customer='.(int)$cart->id_customer.' && card_id='.(int)Tools::getValue('card_id')
                    );
                    $url = 'index.php?fc=module&module=bancard&controller=validation';
                    $url .= '&managecards='.(bool)Tools::getValue('managecards');
                    Tools::redirect($url);
                    break;
            }
        } elseif (Tools::getValue('card_action')) {
            switch (Tools::getValue('card_action')) {
                case 'remove':
                    $alias_token = Tools::getValue('alias_token');
                    $response = BancardApi::removeUserCard(
                        $b_p_k,
                        $b_pr_k,
                        (int)$customer->id,
                        $b_p_m,
                        $alias_token,
                        (bool)Tools::getValue('managecards')
                    );
                    $card_id = Tools::getValue('card_id');
                    Db::getInstance()->delete(
                        'bancard_cutsomer_cards',
                        'id_customer = "'.(int)$customer->id.'" AND card_id = "'.(int)$card_id.'"'
                    );
                    $this->context->smarty->assign(array(
                        'removeUserCard_response' => $response,
                    ));
                    break;
                case 'charge':
                    $this->checkAuthorization();
                    $alias_token = Tools::getValue('alias_token');
                    $description = $this->module->l('Order on shop ').Configuration::get('PS_SHOP_NAME');
                    $responseData = BancardApi::chargeUserCard(
                        $b_p_k,
                        $b_pr_k,
                        $b_p_m,
                        $alias_token,
                        $total,
                        'PYG',
                        $cart->id,
                        $description
                    );
                    $this->validatePayment(
                        $responseData,
                        $total,
                        $cart->id,
                        $b_pr_k,
                        $alias_token,
                        $customer->secure_key
                    );
                    break;
            }
        }

        $this->checkAuthorization();
        if (!isset($_REQUEST['mode_status'])) {
            $address = new Address($ad_inv);
            $phone = $address->phone!=null?$address->phone:'021';
            $email = $customer->email;
            if ($use_token) {

                $b_p_k = Configuration::get('BANCARD_PUBLIC_KEY');
                $b_pr_k = Configuration::get('BANCARD_PRIVATE_KEY');
                $b_p_m = Configuration::get('BANCARD_PAYMENT_MODE');
                $use_token = Configuration::get('BANCARD_PAYMENT_OPTION');

                $cards = BancardApi::bancardGetCustomerCards($b_p_k, $b_pr_k, $customer->id, $b_p_m);
                $process_id = BancardApi::bancardSentdata($b_p_k, $b_pr_k, $cart->id, $total, 'PYG', $b_p_m);
                $bancard_url = 'https://vpos.infonet.com.py'.($b_p_m == 'YES' ? ':8888/' : '/');
                if($b_p_m=='YES'){
                    $bancard_url .= 'checkout/javascript/dist/bancard-checkout-2.1.0.js';
                }else{
                    $bancard_url .= 'checkout/javascript/dist/bancard-checkout-2.1.0.js';
                }

                $this->context->smarty->assign(array(
                    'bancard_url' => $bancard_url,
                    'process_id' => $process_id
                ));

                if (Tools::isSubmit('RegisterNewCard')) {
                    $card_id = Tools::getValue('card_id');
                    if (!$card_id || !Validate::isInt($card_id)) {
                        $url = 'index.php?fc=module&module=bancard&controller=validation';
                        $url .= '&managecards='.(bool)Tools::getValue('managecards');
                        $url .= '&res=e&desc='.urlencode($this->module->l('Invalid Card Id'));
                        Tools::redirect($url);
                    }
                    $ExistingCard = Db::getInstance()->getRow(
                        'SELECT * FROM `'._DB_PREFIX_.'bancard_cutsomer_cards`
                        WHERE `card_id` = "'.(int)$card_id.'" AND
                        id_customer = "'.(int)$customer->id.'"'
                    );

                    if ($ExistingCard) {
                        if ($ExistingCard['success']) {
                            $url = 'index.php?fc=module&module=bancard&controller=validation';
                            $url .= '&managecards='.(bool)Tools::getValue('managecards');
                            $url .= '&res=e&desc='.urlencode($this->module->l('Card Id already exists'));
                            Tools::redirect($url);
                        }
                        Db::getInstance()->delete(
                            'bancard_cutsomer_cards',
                            '`card_id` = "'.(int)$card_id.'" AND id_customer = "'.(int)$customer->id.'"'
                        );
                    }

                    $returnUrl = $this->context->link->getModuleLink(
                        $this->module->name,
                        'validation',
                        array(
                            'add_new_card' => true,
                            'card_id' => $card_id,
                            'managecards' => (bool)Tools::getValue('managecards')
                        )
                    );
                    $process_id = BancardApi::bancardSentTokendata(
                        $b_p_k,
                        $b_pr_k,
                        $customer->id,
                        $card_id,
                        $b_p_m,
                        $phone,
                        $email,
                        $returnUrl,
                        (bool)Tools::getValue('managecards')
                    );


                    Db::getInstance()->insert('bancard_cutsomer_cards', array(
                        'process_id' => pSQL($process_id),
                        'id_customer' => (int)$customer->id,
                        'card_id' => (int)$card_id,
                        'date_added' => pSQL(date('Y-m-d H:i:s'))
                    ));

                    $bancard_url = 'https://vpos.infonet.com.py'.($b_p_m == 'YES' ? ':8888/' : '/');
                    if($b_p_m=='YES'){
                        $bancard_url .= 'checkout/javascript/dist/bancard-checkout-2.1.0.js';
                    }else{
                        $bancard_url .= 'checkout/javascript/dist/bancard-checkout-2.1.0.js';
                    }

                    $this->context->smarty->assign(array(
                        'bancard_url' => $bancard_url,
                        'process_id' => $process_id
                    ));
                    if ($ps_below_7) {
                        $this->setTemplate('payment_token_iframe_1_6.tpl');
                    } else {
                        $this->setTemplate('module:bancard/views/templates/front/payment_token_iframe.tpl');
                    }
                } else {

                    $this->context->smarty->assign(array(
                        'registeredCards' => $cards,
                        'managecards' => Tools::getValue('managecards')
                    ));
                    if ($ps_below_7) {
                        $this->setTemplate('payment_token_1_6.tpl');
                    } else {
                        $this->setTemplate('module:bancard/views/templates/front/payment_token.tpl');
                    }
                    return;
                }
            } else {
                $process_id = BancardApi::bancardSentdata($b_p_k, $b_pr_k, $cart->id, $total, 'PYG', $b_p_m);
                $bancard_url = 'https://vpos.infonet.com.py'.($b_p_m == 'YES' ? ':8888/' : '/');
                if($b_p_m=='YES'){
                    $bancard_url .= 'checkout/javascript/dist/bancard-checkout-2.1.0.js';
                }else{
                    $bancard_url .= 'checkout/javascript/dist/bancard-checkout-2.1.0.js';
                }

                $this->context->smarty->assign(array(
                    'bancard_url' => $bancard_url,
                    'process_id' => $process_id
                ));
                if ($ps_below_7) {
                    $this->setTemplate('payment_iframe_1_6.tpl');
                } else {
                    $this->setTemplate('module:bancard/views/templates/front/payment_iframe.tpl');
                }
            }
        } elseif (isset($_REQUEST['mode_status']) && $_REQUEST['mode_status'] == 'sucess') {
            $cart_id = $_REQUEST['id_cart'];
            $sel_order = 'SELECT * FROM '._DB_PREFIX_.'orders WHERE id_cart = ';
            $order_id = Db::getInstance()->executeS($sel_order.(int)$cart_id.'');
            $id_mod = $this->module->id;
            $sec_key = $customer->secure_key;
            $or_id = $order_id[0]['id_order'];
            $params = 'id_cart='.$_REQUEST['id_cart'].'&id_module='.$id_mod;
            $params .= '&id_order='.$or_id.'&key='.$sec_key;
            Tools::redirect('index.php?controller=order-confirmation&'.$params);
        }
        if (isset($_REQUEST['mode_status']) && $_REQUEST['mode_status'] == 'cancel') {
            $shop_id = $_REQUEST['shop_id'];
            $amount = '0.00';
            $currency_code = 'PYG';
            $b_p_k = Configuration::get('BANCARD_PUBLIC_KEY');
            $b_pr_k = Configuration::get('BANCARD_PRIVATE_KEY');
            $b_p_m = Configuration::get('BANCARD_PAYMENT_MODE');
            BancardApi::bancardRollback($b_p_k, $b_pr_k, $shop_id, $amount, $b_p_m);
            $del_req = 'DELETE FROM '._DB_PREFIX_.'bancard_request
                where shop_process_id = "'.pSQL($shop_id).'"';
            Db::getInstance()->execute($del_req);
            $dis_name = $this->module->displayName;
            $id_cur = (int)$currency->id;
            $se_key = $customer->secure_key;
            $this->module->validateOrder(
                $cart->id,
                '6',
                $total,
                $dis_name,
                null,
                $mail_vars,
                $id_cur,
                false,
                $se_key
            );
            $concate = '&id_order='.$this->module->currentOrder.'&key='.$se_key;
            $param = 'id_cart='.$cart->id.'&id_module='.$this->module->id.$concate;
            Tools::redirect('index.php?controller=order-confirmation&'.$param);
        }
    }
    public function validatePayment(
        $responseData,
        $total,
        $cart_id,
        $private_key,
        $alias_token,
        $secure_key
    ) {
        $total = number_format($total, 2, '.', '');
        $currency = 'PYG';
        $bancard_data = Db::getInstance()->getRow(
            'SELECT * FROM `'._DB_PREFIX_.'bancard_request` WHERE `id_cart` = "'.(int)$cart_id.'"'
        );
        $shopid = '';
        if ($bancard_data) {
            $shopid = $bancard_data['shop_process_id'];
        }
        if ($responseData['response'] == 'S' && $responseData['response_code'] == '00') {
            $t = 1;
            do {
                sleep(1);
                $id_order = $this->module->getOrderByCartId($cart_id);
                $t++;
            } while (!$id_order && $t <= 5);
            

            
           // $concate = '&id_order='.(int)$id_order.'&key='.$secure_key;
            $param = 'id_cart='.$cart_id.'&id_module='.$this->module->id;
            Tools::redirect('index.php?controller=order-confirmation&'.$param);
        } else {
            $url = 'index.php?fc=module&module=bancard&controller=payment';
            $url .= '&managecards='.(bool)Tools::getValue('managecards');
            $url .= '&res=e&desc='.urlencode(
                $this->module->l('Respuesta no válida de bancard. Por favor, póngase en contacto con el administrador de la tienda.')
            );
            Tools::redirect($url);
        }
    }

    public function checkAuthorization()
    {
        $authorized = false;

        foreach (PaymentModule::getInstalledPaymentModules() as $module) {
            if ($module['name'] == 'bancard') {
                $authorized = true;
                break;
            }
        }

        if (!$authorized || !$this->module->currencyEnable()) {
            Tools::redirect($this->context->link->getPageLink('order', true, null, array('step' => 1)));
        }

        $cart = $this->context->cart;
        $cust_id = $cart->id_customer;
        $add_del = $cart->id_address_delivery!=null?$cart->id_address_delivery:'1';
        $ad_inv = $cart->id_address_invoice!=null?$cart->id_address_invoice:'1';
        if ($cust_id == 0 || $add_del == 0 || $ad_inv == 0 || !$this->module->active) {
            Tools::redirect($this->context->link->getPageLink('order', true, null, array('step' => 1)));
        }

        $customer = new Customer($cart->id_customer);

        if (!Validate::isLoadedObject($customer)) {
            Tools::redirect($this->context->link->getPageLink('order', true, null, array('step' => 1)));
        }
    }
}
