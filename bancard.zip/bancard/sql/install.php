<?php
$sql = array();
$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'bancard_response`
        (`id_cart` INT( 11 ) NOT NULL ,
        `order_number` VARCHAR( 155 ) NOT NULL ,
        `response_code` VARCHAR( 15 ) NOT NULL ,
        `response_description` VARCHAR( 255 ) NOT NULL ,
        `authorization_number` VARCHAR( 15 ) NOT NULL);';
$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'bancard_request`
        (`shop_process_id` varchar( 255 ) NOT NULL ,
        `id_cart` INT( 11 ) NOT NULL ,
        `date_added` datetime NOT NULL ,
        `rollback_time` datetime NOT NULL );';
$sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'bancard_cutsomer_cards`
        (`process_id` varchar( 255 ) NOT NULL ,
        `id_customer` INT( 11 ) NOT NULL ,
        `card_id` INT( 11 ) NOT NULL ,
        `success` TINYINT NOT NULL DEFAULT 0,
        `date_added` datetime NOT NULL,
        PRIMARY KEY (`id_customer`, `card_id`) );';
foreach ($sql as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}
