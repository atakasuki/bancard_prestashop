<?php
$sql = array();
$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'bancard_response`';
$sql[] = 'DROP TABLE IF EXISTS `'._DB_PREFIX_.'bancard_request`';

foreach ($sql as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}
