#Bancard
#Accept payments for your products via credit card
#This module only accepts payment in currency "Paraguay Guarani [PYG]"
#Please set up this return URL on the bancard official site : SITE_URL "/modules/bancard/response.php"