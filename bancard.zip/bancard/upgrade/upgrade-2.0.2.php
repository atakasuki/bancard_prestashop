<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_2_0_2()
{
    $sql = array();
    $sql[] = 'CREATE TABLE IF NOT EXISTS `'._DB_PREFIX_.'bancard_cutsomer_cards`
        (`process_id` varchar( 255 ) NOT NULL ,
        `id_customer` INT( 11 ) NOT NULL ,
        `card_id` INT( 11 ) NOT NULL ,
        `success` TINYINT NOT NULL DEFAULT 0,
        `date_added` datetime NOT NULL,
        PRIMARY KEY (`id_customer`, `card_id`) );';

    foreach ($sql as $query) {
        if (Db::getInstance()->execute($query) == false) {
            return false;
        }
    }
    if (!Configuration::get('BANCARD_PAYMENT_OPTION')) {
        Configuration::updateValue('BANCARD_PAYMENT_OPTION', 1);
    }
    return true;
}
