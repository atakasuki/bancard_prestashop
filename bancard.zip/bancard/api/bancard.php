<?php
class BancardApi
{
    
    public function __construct()
    {
        ob_start();
        require_once dirname(dirname(dirname(dirname(__FILE__)))).'/config/config.inc.php';
        require_once dirname(dirname(dirname(dirname(__FILE__)))).'/init.php';
    }

    public static function bancardSentdata($public_key, $private_key, $shopid, $amount, $currency, $mode)
    {
        global $cookie;

        $currency_actual = new Currency($cookie->id_currency);

        if ($currency_actual->iso_code != 'PYG') {
            $currencyGp = new Currency(Currency::getIdByIsoCode('PYG'));
            $amount = $amount * (float)$currencyGp->conversion_rate;
        }

        $id_cart = $shopid;
        $description = 'Order #'.$shopid;
        $shopid = $shopid.time();
        $amount = number_format($amount, 2, '.', '');
        $token = md5($private_key.$shopid.$amount.$currency);
        $context = Context::getContext();
        $return_success = $context->link->getModuleLink(
            'bancard',
            'validation',
            array(
                'mode_status' => 'sucess',
                'id_cart' => $id_cart,
                'shop_id' => $shopid,
            )
        );
        $return_cancel = $context->link->getModuleLink(
            'bancard',
            'validation',
            array(
                'mode_status' => 'cancel',
                'shop_id' => $shopid,
            )
        );
        $data = '{"public_key":  "'.$public_key.'" ,
            "operation": {
            "token":  "'.$token.'" ,
            "shop_process_id":'.$shopid.',
            "amount":  "'.$amount.'",
            "currency":  "'.$currency.'" ,
            "additional_data":  "" ,
            "description":   "'.$description.'"  ,
            "return_url":  "'.$return_success.'",
            "cancel_url":  "'.$return_cancel.'"
        }}';
        $buffer = BancardApi::curlIt($mode, 'single_buy', 'POST', $data, false, false);

        if (empty($buffer)) {
            Tools::redirect($context->link->getModuleLink(
                'bancard',
                'payment',
                array('res'=>'e')
            ));
        } else {
            $sucess = $buffer;
            if ($sucess['status'] == 'success' && $sucess['process_id'] != '') {
                $date = date('Y-m-d H:i:s');
                $current_date = strtotime($date);
                $future_date = $current_date + (60 * 15);
                $format_date = date('Y-m-d H:i:s', $future_date);
                $del_query = 'DELETE FROM '._DB_PREFIX_.'bancard_request where id_cart = "'.(int)$id_cart.'"';
                Db::getInstance()->execute($del_query);
                $ssql = 'INSERT INTO '._DB_PREFIX_.'bancard_request SET
                id_cart = '.(int)$id_cart.',
                shop_process_id = "'.pSQL($shopid).'",
                date_added = "'.date('Y-m-d H:i:s').'",
                rollback_time = "'.$format_date.'"';
                Db::getInstance()->execute($ssql);
                return $sucess['process_id'];
            } else {
                Tools::redirect($context->link->getModuleLink(
                    'bancard',
                    'payment',
                    array('res'=>'e')
                ));
            }
        }
    }

    public static function bancardSentTokendata(
        $public_key,
        $private_key,
        $user_id,
        $card_id,
        $mode,
        $phone,
        $email,
        $returnUrl,
        $managecards
    ) {
        $token = md5($private_key.$card_id.$user_id."request_new_card");
        $data = array(
            'public_key' => $public_key,
            'operation' => array(
                'token' => $token,
                'card_id' => $card_id,
                'user_id' => $user_id,
                'user_cell_phone' => $phone,
                'user_mail' => $email,
                "return_url" =>  $returnUrl
            )
        );
        if ($mode == 'YES') {
            //$data['test_client'] = true;
        }
        $data = json_encode($data);
        $buffer = BancardApi::curlIt($mode, 'cards/new', 'POST', $data, false, false);

        if (empty($buffer)) {
            Tools::redirect(Context::getContext()->link->getModuleLink(
                'bancard',
                'payment',
                array('res'=>'e')
            ));
        } else {
            $sucess = $buffer;
            if ($sucess['status'] == 'success' && $sucess['process_id'] != '') {
                return $sucess['process_id'];
            } else {
                $params = array(
                    'res'=>'e',
                    'managecards' => $managecards
                );
                if (isset($sucess['messages'])) {
                    $params['desc'] = $sucess['messages'][0]['dsc'];
                }
                Tools::redirect(Context::getContext()->link->getModuleLink(
                    'bancard',
                    'payment',
                    $params
                ));
            }
        }
    }

    public static function bancardGetCustomerCards($public_key, $private_key, $user_id, $mode)
    {
        $token = md5($private_key.$user_id."request_user_cards");
        $data = array(
            'public_key' => $public_key,
            'operation' => array(
                'token' => $token,
            )
        );
        if ($mode == 'YES') {
            //$data['test_client'] = true;
        }
        $data = json_encode($data);
        $buffer = BancardApi::curlIt($mode, 'users/'.$user_id.'/cards', 'POST', $data, false, false);

        if (empty($buffer)) {
            Tools::redirect(Context::getContext()->link->getModuleLink(
                'bancard',
                'validation',
                array('res'=>'e', 'managecards' => Tools::getValue('managecards'))
            ));
        } else {
            $sucess = $buffer;
            if ($sucess['status'] == 'success') {
                return $sucess['cards'];
            } else {
                $params = array(
                    'res'=>'e',
                    'managecards' => Tools::getValue('managecards')
                );
                if (isset($sucess['messages'])) {
                    $params['desc'] = $sucess['messages'][0]['dsc'];
                }
                Tools::redirect(Context::getContext()->link->getModuleLink(
                    'bancard',
                    'validation',
                    $params
                ));
            }
        }
    }

    public static function chargeUserCard(
        $public_key,
        $private_key,
        $mode,
        $alias_token,
        $total,
        $currency,
        $cart_id,
        $description
    ) {

        global $cookie;

        $currency_actual = new Currency($cookie->id_currency);

        if ($currency_actual->iso_code != 'PYG') {
            $currencyGp = new Currency(Currency::getIdByIsoCode('PYG'));
            $total = $total * (float)$currencyGp->conversion_rate;
        }

        $shopid = $cart_id.time();
        $total = number_format($total, 2, '.', '');
        $token = md5($private_key.$shopid."charge".$total.$currency.$alias_token);
        $data = array(
            'public_key' => $public_key,
            'operation' => array(
                'token' => $token,
                'shop_process_id' => $shopid,
                'number_of_payments' => '1',
                'additional_data' => '',
                'description' => $description,
                'alias_token' => $alias_token,
                'amount' => $total,
                'currency' => $currency
            )
        );

        if ($mode == 'YES') {
            //$data['test_client'] = true;
        }
        $data = json_encode($data);
        
        $buffer = BancardApi::curlIt($mode, 'charge', 'POST', $data, false, false);
        if (empty($buffer)) {
            Tools::redirect(Context::getContext()->link->getModuleLink(
                'bancard',
                'payment',
                array('res'=>'e')
            ));
        } else {
            $sucess = $buffer;
            if ($sucess['status'] == 'success') {
                $date = date('Y-m-d H:i:s');
                $rollback_date = date(
                    'Y-m-d H:i:s',
                    strtotime($date) + (60 * 15)
                );

                Db::getInstance()->delete(
                    'bancard_request',
                    'id_cart = "'.(int)$cart_id.'"'
                );
                Db::getInstance()->insert(
                    'bancard_request',
                    array(
                        'id_cart' => (int)$cart_id,
                        'shop_process_id' => pSQL($shopid),
                        'date_added' => pSQL($date),
                        'rollback_time' => pSQL($rollback_date)
                    )
                );
                return $sucess['confirmation'];
            } else {
                $params = array(
                    'res'=>'e',
                    'managecards' => Tools::getValue('managecards')
                );
                if (isset($sucess['messages'])) {
                    $params['desc'] = $sucess['messages'][0]['dsc'];
                }
                Tools::redirect(Context::getContext()->link->getModuleLink(
                    'bancard',
                    'validation',
                    $params
                ));
            }
        }
    }

    public static function removeUserCard($public_key, $private_key, $user_id, $mode, $access_token, $managecards)
    {
        $token = md5($private_key."delete_card".$user_id.$access_token);
        $context = Context::getContext();
        $redirectUrl = $context->link->getModuleLink(
            'bancard',
            'validation',
            array('res' => 'e', 'managecards' => $managecards)
        );
        $data = array(
            'public_key' => $public_key,
            'operation' => array(
                'token' => $token,
                'alias_token' => $access_token
            )
        );
        if ($mode == 'YES') {
            ////$data['test_client'] = true;
        }
        $data = json_encode($data);
        $buffer = BancardApi::curlIt($mode, 'users/'.$user_id.'/cards', 'DELETE', $data, false, false);
        if (empty($buffer)) {
            Tools::redirect($redirectUrl);
        } else {
            $sucess = $buffer;
            if ($sucess['status'] == 'success') {
                return true;
            } else {
                return false;
            }
        }
    }

    public static function bancardRollback($public_key, $private_key, $shopid, $amount, $mode)
    {
        $rollback = 'rollback';
        $amount = '0.00';
        $token = md5($private_key.$shopid.$rollback.$amount);
        $data = array(
            'public_key' => $public_key,
            'operation' => array(
                'token' => $token,
                'shop_process_id' => $shopid,
            )
        );

        if ($mode == 'YES') {
            //$data['test_client'] = true;
        }
        $data = json_encode($data);

        $buffer = BancardApi::curlIt($mode, 'single_buy/rollback', 'POST', $data);
        if (empty($buffer)) {
            print 'Nothing returned from url.<p>';
        } else {
            $sucess = $buffer;
            return $sucess;
        }
    }

    public static function bancardConfirmation(
        $public_key,
        $private_key,
        $shopid,
        $cart_id,
        $id_order,
        $amount,
        $mode
    ) {
        $get_confirmation = 'get_confirmation';
        $amount = number_format($amount, 2, '.', '');
        $token = md5($private_key.$shopid.$get_confirmation);
        $data = array(
            'public_key' => $public_key,
            'operation' => array(
                'token' => $token,
                'shop_process_id' => $shopid,
            )
        );

        if ($mode == 'YES') {
            //$data['test_client'] = true;
        }
        $data = json_encode($data);

        $buffer = BancardApi::curlIt($mode, 'single_buy/confirmations', 'POST', $data);
        $objOrder = new Order($id_order);
        $history = new OrderHistory();
        $history->id_order = (int)$objOrder->id;
        if (empty($buffer)) {
            $history->changeIdOrderState(_PS_OS_ERROR_, (int)($objOrder->id));
            echo('Oops, something went wrong. There is no response from Bancard API.');
        } else {
            $sucess = $buffer;
            $db = Db::getInstance();
            if ($sucess['status'] == 'success' && $sucess['confirmation']) {
                $conId = $sucess['confirmation']['shop_process_id'];
                $del_b_r = 'DELETE FROM '._DB_PREFIX_.'bancard_response where order_number = "'.$conId.'"';
                $db->execute($del_b_r);

                $query = 'INSERT INTO '._DB_PREFIX_.'bancard_response SET
                id_cart = '.(int)$cart_id.',
                order_number = "'.$conId.'",
                response_code = "'.$sucess['confirmation']['response_code'].'",
                response_description = "'.$sucess['confirmation']['response_description'].'",
                authorization_number = "'.$sucess['confirmation']['authorization_number'].'"';
                $db->execute($query);
                $del_req = 'DELETE FROM '._DB_PREFIX_.'bancard_request where shop_process_id = "'.$conId.'"';
                $db->execute($del_req);
                
                if ($sucess['confirmation']['response'] == 'S' &&
                    $sucess['confirmation']['response_code'] == '00'
                ) {
                    $history->changeIdOrderState(
                        Configuration::get('BANCARD_PAYMENT_COMPLETE'),
                        (int)($objOrder->id)
                    );
                    echo('Exito, tu orden cambio de estado a confirmado.');
                } else {
                    $history->changeIdOrderState(_PS_OS_ERROR_, (int)($objOrder->id));
                    echo('Oops, no pudimos proceso su transacción por la api de Bancard.');
                }
            } else {
                $history->changeIdOrderState(_PS_OS_ERROR_, (int)($objOrder->id));
                if (isset($sucess['messages'])) {
                    $ret_msg = $sucess['messages'][0]['dsc'];
                } else {
                    $ret_msg = 'Oops, Hubo un error durante el proceso de pago.';
                }
                echo($ret_msg);
            }
        }
    }

    public static function curlIt(
        $demoMode = 'YES',
        $method_string = null,
        $request_type = 'POST',
        $data = null,
        $ssl_verifyhost = null,
        $ssl_verifypeer = null
    ) {
        if ($method_string == null || $data == null) {
            return ;
        }
        $url = 'https://vpos.infonet.com.py';
        if ($demoMode == 'YES') {
            $url .= ':8888';
        }
        $url .= '/vpos/api/0.3/'.$method_string;
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 400);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $request_type);
        $result = curl_exec($ch);
        $result = json_decode($result, false);
        $result = json_decode(json_encode($result), true);
        curl_close($ch);

        return $result;
    }
}
