<?php
class Bancard extends PaymentModule
{
    private $html = '';
    private $post_errors = array();

    public $details;
    public $owner;
    public $address;
    public $extra_mail_vars;
    public $ps_below_7;

    public function __construct()
    {
        require_once dirname(__FILE__).'/api/bancard.php';

        $this->name = 'bancard';
        $this->tab = 'payments_gateways';
        $this->version = '0.1';
        $this->author = 'Bancard S.A.';
        $this->public_key = '';
        $this->private_key = '';
        $this->order_status = '';
        $this->payment_mode = '';
        $this->need_instance = 1;
        $this->module_key = '5cf577c4048b501e3e74b0ec93158e44';
        $this->controllers = array('payment', 'validation');
        $this->currencies = true;
        $this->currencies_mode = 'checkbox';
        $get_arr = array('BANCARD_PUBLIC_KEY', 'BANCARD_PRIVATE_KEY', 'BANCARD_ORDER_STATUS', 'BANCARD_PAYMENT_MODE');
        $config = Configuration::getMultiple($get_arr);
        if (isset($config['BANCARD_PUBLIC_KEY'])) {
            $this->public_key = $config['BANCARD_PUBLIC_KEY'];
        }
        if (isset($config['BANCARD_PRIVATE_KEY'])) {
            $this->private_key = $config['BANCARD_PRIVATE_KEY'];
        }
        if (isset($config['BANCARD_ORDER_STATUS'])) {
            $this->order_status = $config['BANCARD_ORDER_STATUS'];
        }
        if (isset($config['BANCARD_PAYMENT_MODE'])) {
            $this->payment_mode = $config['BANCARD_PAYMENT_MODE'];
        }
        $this->bootstrap = true;
        parent::__construct();
        $this->displayName = $this->l('Bancard');
        $this->description = $this->l('Habilitar pagos con tarjeta de créditos o débito para tu ecommerce.');
        $this->confirmUninstall = $this->l('Esta seguro de eliminar este módulo?');
        if (!function_exists('curl_version')) {
            $this->warning = $this->l('la extensión cURL debe estar habilitada en su servidor para usar este módulo.');
        }
        $update_config = array(
            'PS_OS_BANCARD',
            'PS_OS_CHEQUE',
            'PS_OS_PAYMENT',
            'PS_OS_PREPARATION',
            'PS_OS_SHIPPING',
            'PS_OS_CANCELED',
            'PS_OS_REFUND',
            'PS_OS_ERROR',
            'PS_OS_OUTOFSTOCK',
            'PS_OS_BANKWIRE',
            'PS_OS_PAYPAL',
            'PS_OS_WS_PAYMENT'
        );
        $this->ps_below_7 = Tools::version_compare(_PS_VERSION_, '1.7', '<');
        if (!Configuration::get('PS_OS_BANCARD')) {
            foreach ($update_config as $u) {
                if (!Configuration::get($u) && defined('_'.$u.'_')) {
                    Configuration::updateValue($u, constant('_'.$u.'_'));
                }
            }
        }
    }

    public function createAjaxController()
    {
        $tab = new Tab();
        $tab->active = 1;
        $languages = Language::getLanguages(false);
        if (is_array($languages)) {
            foreach ($languages as $language) {
                $tab->name[$language['id_lang']] = 'buyconfirmation';
            }
        }
        $tab->class_name = 'BuyConfirmation';
        $tab->module = $this->name;
        $tab->id_parent = - 1;
        return (bool)$tab->add();
    }

    private function removeAjaxContoller()
    {
        if ($tab_id = (int)Tab::getIdFromClassName('BuyConfirmation')) {
            $tab = new Tab($tab_id);
            $tab->delete();
        }
        return true;
    }

    public function install()
    {
        include(dirname(__FILE__).'/sql/install.php');

        if (!parent::install()
        || !$this->registerHook('paymentReturn')
        || !$this->registerHook('header')
        || !$this->registerHook('displayAdminOrder')
        || !$this->registerHook('displayOrderDetail')
        || !$this->registerHook('updateOrderStatus')
        || !$this->registerHook('displayHeader')
        || !$this->registerHook('displayCustomerAccount')
        || !$this->createAjaxController()) {
            return false;
        }
        if ($this->ps_below_7) {
            if (!$this->registerHook('payment')) {
                return false;
            }
        } else {
            if (!$this->registerHook('paymentOptions')) {
                return false;
            }
        }
        $this->setStatus();
        return true;
    }

    public function uninstall()
    {
        include(dirname(__FILE__).'/sql/uninstall.php');
        if (!Configuration::deleteByName('BANCARD_PUBLIC_KEY')
        || !Configuration::deleteByName('BANCARD_PRIVATE_KEY')
        || !Configuration::deleteByName('BANCARD_ORDER_STATUS')
        || !Configuration::deleteByName('BANCARD_PAYMENT_OPTION')
        || !$this->removeAjaxContoller()
        || !parent::uninstall()) {
            return false;
        }
        return true;
    }

    protected function setStatus()
    {
        $status = array();
        $status['send_email'] = true;
        $status['invoice'] = false;
        $status['unremovable'] = true;
        $status['paid'] = false;
        $status['template'] = '';
        if (!Configuration::get('BANCARD_PAYMENT_WAITING')) {
            $add_state = $this->addState($this->l('Bancard Pendiente de Pago'), '#0404B4', $status);
            Configuration::updateValue('BANCARD_PAYMENT_WAITING', $add_state);
        }
        if (!Configuration::get('BANCARD_PAYMENT_COMPLETE')) {
            $status['send_email'] = true;
            $status['invoice'] = true;
            $status['unremovable'] = true;
            $status['paid'] = true;
            $status['template'] = 'payment';
            $add_sta_val = $this->addState($this->l('Bancard Pagado'), '#088A29', $status);
            Configuration::updateValue('BANCARD_PAYMENT_COMPLETE', $add_sta_val);
        }
        if (!Configuration::get('BANCARD_ORDER_STATUS')) {
            Configuration::updateValue('BANCARD_ORDER_STATUS', 0);
        }
        if (!Configuration::get('BANCARD_PAYMENT_OPTION')) {
            Configuration::updateValue('BANCARD_PAYMENT_OPTION', 1);
        }
    }

    private function postValidation()
    {
        if (Tools::isSubmit('btnSubmit')) {
            if (!Tools::getValue('BANCARD_PUBLIC_KEY')) {
                $this->post_errors[] = $this->l('Clave pública es requeridad.');
            }

            if (!Tools::getValue('BANCARD_PRIVATE_KEY')) {
                $this->post_errors[] = $this->l('Clave privada es requerida.');
            }
        }
    }

    private function postProcess()
    {
        if (Tools::isSubmit('btnSubmit')) {
            Configuration::updateValue('BANCARD_PUBLIC_KEY', Tools::getValue('BANCARD_PUBLIC_KEY'));
            Configuration::updateValue('BANCARD_PRIVATE_KEY', Tools::getValue('BANCARD_PRIVATE_KEY'));
            Configuration::updateValue('BANCARD_PAYMENT_OPTION', Tools::getValue('BANCARD_PAYMENT_OPTION'));
            Configuration::updateValue('BANCARD_ORDER_STATUS', 'Pending');
            if (Tools::getValue('payment_mode') == '1') {
                Configuration::updateValue('BANCARD_PAYMENT_MODE', 'YES');
            } else {
                Configuration::updateValue('BANCARD_PAYMENT_MODE', 'NO');
            }
        }
        $this->html .= $this->displayConfirmation($this->l('Settings updated'));
    }

    private function displayBancard()
    {
        return $this->display(__FILE__, 'infos.tpl');
    }

    public function getContent()
    {
        if (Tools::isSubmit('btnSubmit')) {
            $this->postValidation();
            if (!count($this->post_errors)) {
                $this->postProcess();
            } else {
                foreach ($this->post_errors as $err) {
                    $this->html .= $this->displayError($err);
                }
            }
        } else {
            $this->html .= '<br />';
        }
        $this->html .= $this->displayBancard();
        $this->html .= $this->renderForm();

        return $this->html;
    }

    public function hookPayment($params)
    {
        if (!$this->active) {
            return;
        }
        // if (!$this->currencyEnable()) {
        //     return;
        // }

        foreach ($params['cart']->getProducts() as $product) {
            $pd = ProductDownload::getIdFromIdProduct((int)$product['id_product']);
            if ($pd && Validate::isUnsignedInt($pd)) {
                return false;
            }
        }

        $this->smarty->assign(
            array(
                'this_path' => $this->_path, //keep for retro compat
                'this_path_cod' => $this->_path,
                'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->name.'/'
            )
        );
        return $this->display(__FILE__, 'payment_1_6.tpl');
    }

    public function currencyEnable()
    {
        $currency = new Currency($this->context->cart->id_currency);
        if ($currency->iso_code != 'PYG') {
            return true;
        } else {
            return true;
        }
    }

    public function hookPaymentOptions($params)
    {
        if (!$this->active) {
            return;
        }
        if (!$this->currencyEnable()) {
            return;
        }

        foreach ($params['cart']->getProducts() as $product) {
            $pd = ProductDownload::getIdFromIdProduct((int)$product['id_product']);
            if ($pd && Validate::isUnsignedInt($pd)) {
                return false;
            }
        }

        $info = $this->getTranslator()->trans("Pago Seguro con Bancard", array(), 'Modules.Bancard');
        $newOption = new PrestaShop\PrestaShop\Core\Payment\PaymentOption;
        $newOption->setCallToActionText(
            $this->getTranslator()->trans('Pago con Tarjeta de Crédito o Débito', array(), 'Modules.Bancard')
        );
        $newOption->setAction($this->context->link->getModuleLink($this->name, 'payment', array(), true));
        $newOption->setAdditionalInformation($info);
        $payment_options = array();
        $payment_options[] = $newOption;

        return $payment_options;
    }

    public function hookPaymentReturn($params)
    {
        if (!$this->active) {
            return;
        }
        if ($this->ps_below_7) {
            $state = $params['objOrder']->getCurrentState();
            $total_to_pay = Tools::displayPrice($params['total_to_pay'], $params['currencyObj'], false);
            $order_id = $params['objOrder']->id;
            $reference = isset($params['objOrder']->reference) && !empty($params['objOrder']->reference);
        } else {
            $paid = $params['order']->getOrdersTotalPaid();
            $state = $params['order']->getCurrentState();
            $total_to_pay = Tools::displayPrice($paid, new Currency($params['order']->id_currency), false);
            $order_id = $params['order']->id;
            $reference = isset($params['order']->reference) && !empty($params['order']->reference);
        }
        if ($state) {
            if ($state == _PS_OS_ERROR_) {
                $status = 'cancel';
                $response_code = '';
            } elseif ($state = (int)Configuration::get('PS_OS_PAYMENT')) {
                $status = 'ok';
                $response_code = '00';
            } else {
                $status = 'ok';
                $response_code = '';
            }

            $this->smarty->assign(array(
                'total_to_pay' => $total_to_pay,
                'status' => $status,
                'shop_name' => Configuration::get('PS_SHOP_NAME'),
                'response_date' => date('Y-m-d H:i:s') ,
                'response_code' => $response_code ,
                'id_order' => $order_id
            ));
            if ($reference) {
                if ($this->ps_below_7) {
                    $this->smarty->assign('reference', $params['objOrder']->reference);
                } else {
                    $this->smarty->assign('reference', $params['order']->reference);
                }
            }
        } else {
            $this->smarty->assign('status', 'failed');
        }
        
        if ($this->ps_below_7) {
            return $this->display(__FILE__, 'payment_return.tpl');
        } else {
            return $this->fetch('module:bancard/views/templates/hook/payment_return.tpl');
        }
    }

    public function hookDisplayAdminOrder()
    {
        $order_id = Tools::getValue('id_order');
        $order = new Order($order_id);

        if ($order->module == 'bancard') {
            $br_result = $this->getOrderResponse();

            $this->context->smarty->assign(array(
                'id_order' => (int)($order_id),
                'ajaxlink' => $this->context->link->getAdminLink('BuyConfirmation'),
                'ban_card_message' => $br_result
            ));
            if ($this->ps_below_7) {
                return $this->display(__FILE__, 'invoice_details.tpl');
            } else {
                return $this->fetch('module:bancard/views/templates/hook/invoice_details.tpl');
            }
        }
    }

    public function getOrderResponse()
    {
        $order_id = Tools::getValue('id_order');
        $qury = 'SELECT br.* FROM '._DB_PREFIX_.'bancard_response br
        LEFT JOIN '._DB_PREFIX_.'orders o ON br.id_cart=o.id_cart
        WHERE o.id_order='.$order_id;
        return Db::getInstance()->executeS($qury);
    }

    public function hookDisplayOrderDetail()
    {
        $br_result = $this->getOrderResponse();
        $this->context->smarty->assign('ban_card_message', $br_result);
        if ($this->ps_below_7) {
            return $this->display(__FILE__, 'front_invoice_details.tpl');
        } else {
            return $this->fetch('module:bancard/views/templates/hook/front_invoice_details.tpl');
        }
    }

    public function getOrderByCartId($id_cart)
    {
        $res = Db::getInstance()->getRow(
            'SELECT * FROM `'._DB_PREFIX_.'orders` WHERE `id_cart` = "'.(int)$id_cart.'"'
        );
        if ($res) {
            return $res['id_order'];
        }
        return false;
    }

    public function hookUpdateOrderStatus($params)
    {
        if (!Validate::isLoadedObject($params['newOrderStatus'])) {
            die($this->l('Parámetros no encontrados'));
        }
        $new_order = $params['newOrderStatus'];
        $order = new Order((int)$params['id_order']);
        if ($order && !Validate::isLoadedObject($order)) {
            die($this->l('Orden incorrecta.'));
        }
        if($order->module=='bancard'){
            $pk_arr = array('BANCARD_PUBLIC_KEY', 'BANCARD_PRIVATE_KEY', 'BANCARD_PAYMENT_MODE');
            $config = Configuration::getMultiple($pk_arr);
            $b_p_key = $config['BANCARD_PUBLIC_KEY'];
            $bancard_private_key = $config['BANCARD_PRIVATE_KEY'];
            $b_p_mode = $config['BANCARD_PAYMENT_MODE'];
            $get_cancel = Configuration::get('PS_OS_CANCELED');
            if ($new_order->id == $get_cancel || $new_order->id == Configuration::get('PS_OS_REFUND')) {
                $query = 'SELECT * FROM '._DB_PREFIX_.'bancard_response WHERE id_cart = '.(int)$order->id_cart;
                $responsedata = Db::getInstance()->getRow($query);
                if ($responsedata) {
                    $shopid = $responsedata['order_number'];
                    $amount = ' 0.00';
                    BancardApi::bancardRollback($b_p_key, $bancard_private_key, $shopid, $amount, $b_p_mode);
                }
            }
        }
    }

    private function addState($en, $color, $status)
    {
        $order_state = new OrderState();
        $order_state->name = array();
        foreach (Language::getLanguages() as $language) {
            $order_state->name[$language['id_lang']] = $en;
        }
        $order_state->name[$this->context->language->id] = $en;
        $order_state->send_email = $status['send_email'];
        $order_state->color = $color;
        $order_state->hidden = false;
        $order_state->unremovable = $status['unremovable'];
        $order_state->delivery = false;
        $order_state->logable = false;
        $order_state->invoice = $status['invoice'];
        $order_state->paid = $status['paid'];
        $order_state->template = $status['template'];
        if ($order_state->add()) {
            if (file_exists(dirname(__FILE__).'/logo.gif')) {
                $dir_name = dirname(__FILE__).'/../../img/os/';
                Tools::copy(dirname(__FILE__).'/logo.gif', $dir_name.(int)$order_state->id.'.gif');
            }
        }
        return $order_state->id;
    }

    public function checkCurrency($cart)
    {
        $currency_order = new Currency($cart->id_currency);
        $currencies_module = $this->getCurrency($cart->id_currency);
        if (is_array($currencies_module)) {
            foreach ($currencies_module as $currency_module) {
                if ($currency_order->id == $currency_module['id_currency']) {
                    return true;
                }
            }
        }
        return false;
    }

    public function renderForm()
    {
        $fields_form = array(
            'form' => array(
                'legend' => array(
                    'title' => $this->l('Detalles de Bancard'),
                    'icon' => 'icon-envelope'
                ),
                'input' => array(
                    array(
                        'type' => 'text',
                        'label' => $this->l('Clave pública'),
                        'name' => 'BANCARD_PUBLIC_KEY',
                        'desc' => $this->l('Clave pública.')
                    ),
                    array(
                        'type' => 'text',
                        'label' => $this->l('Clave privada'),
                        'name' => 'BANCARD_PRIVATE_KEY',
                        'desc' => $this->l('Clave privada.')
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l(' Pagar con alias token '),
                        'name' => 'BANCARD_PAYMENT_OPTION',
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->l('Habilitar')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->l('Desabilitar')
                            )
                        ),
                    ),
                    array(
                        'type' => 'switch',
                        'label' => $this->l(' Modo desarrollo'),
                        'name' => 'payment_mode',
                        'desc' => $this->l('Se habilita el modo de desarrollo.'),
                        'values' => array(
                            array(
                                'id' => 'active_on',
                                'value' => 1,
                                'label' => $this->l('Habilitar')
                            ),
                            array(
                                'id' => 'active_off',
                                'value' => 0,
                                'label' => $this->l('Desabilitar')
                            )
                        ),
                    ),
                ),
                'submit' => array(
                    'title' => $this->l('Save'),
                )
            ),
        );
        $helper = new HelperForm();
        $helper->show_toolbar = false;
        $helper->table = $this->table;
        $lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
        $helper->default_form_language = $lang->id;
        $gEmp = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG');
        $helper->allow_employee_form_lang = $gEmp ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
        $this->fields_form = array();
        $helper->id = (int)Tools::getValue('id_carrier');
        $helper->identifier = $this->identifier;
        $helper->submit_action = 'btnSubmit';
        $params = '&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
        $helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).$params;
        $helper->token = Tools::getAdminTokenLite('AdminModules');
        $helper->tpl_vars = array(
            'fields_value' => $this->getConfigFieldsValues(),
            'languages' => $this->context->controller->getLanguages(),
            'id_language' => $this->context->language->id
        );
        return $helper->generateForm(array($fields_form));
    }

    public function getConfigFieldsValues()
    {
        $p_mode = Configuration::get('BANCARD_PAYMENT_MODE');
        return array(
        'BANCARD_PUBLIC_KEY' => Tools::getValue('BANCARD_PUBLIC_KEY', Configuration::get('BANCARD_PUBLIC_KEY')),
        'BANCARD_PRIVATE_KEY' => Tools::getValue('BANCARD_PRIVATE_KEY', Configuration::get('BANCARD_PRIVATE_KEY')),
        'BANCARD_PAYMENT_OPTION' => Tools::getValue(
            'BANCARD_PAYMENT_OPTION',
            Configuration::get('BANCARD_PAYMENT_OPTION')
        ),
        'payment_mode' => Tools::getValue('payment_mode', ($p_mode == 'YES'?'1':'0')),
        );
    }

    public function hookDisplayHeader()
    {
        $this->context->controller->addCSS($this->_path.'views/css/bancard.css', 'all');
    }

    public function hookDisplayCustomerAccount($params)
    {
        if ($this->ps_below_7) {
            return $this->display(__FILE__, 'my-account-1-6.tpl');
        } else {
            return $this->fetch('module:bancard/views/templates/hook/my-account.tpl');
        }
    }
}
